# Источники и донорские skills

Актуальность базового поиска: 2026-08-23.

## Научные опоры
- WHO. Healthy diet. 26 January 2026.
  https://www.who.int/news-room/fact-sheets/detail/healthy-diet
- WHO Europe. Nutrition for a healthy life. 18 July 2025.
  https://www.who.int/europe/news-room/fact-sheets/item/nutrition---maintaining-a-healthy-lifestyle
- Nordic Nutrition Recommendations 2023.
  https://pub.norden.org/nord2023-003/
- National Academies. Dietary Reference Intakes.
  https://www.nationalacademies.org/dri
- EFSA Dietary Reference Values.
  https://www.efsa.europa.eu/en/topics/topic/dietary-reference-values

## Food composition
- FAO/INFOODS:
  https://www.fao.org/food-composition/en/
- Global directory:
  https://www.fao.org/food-composition/tables-and-databases/en
- BEDCA Spain:
  https://www.bedca.net/
- ANSES-CIQUAL 2025:
  https://ciqual.anses.fr/
- USDA FoodData Central:
  https://fdc.nal.usda.gov/

## Изученные donor skills
- npapatheodorou/personal-trainer-skill — persistence, profile/logs, progressive disclosure.
- NousResearch/hermes-agent fitness-nutrition — calculators + USDA lookup.
- printing-press-library pp-nutrition — food database operations and nutrient comparisons.
- ronkommoji/nutrition-mcp — estimate → confirm → log discipline.
- runyuan-wang/nutrition-skill-methodology — traceability и source-linked distillation.
- prashant-cr/skills weight-loss-diet-plan — practical menu/adherence logic.

## Что сознательно не копируется
- weight-loss-first routing;
- universal macro splits;
- protein 1.6–2.2 g/kg for everyone;
- calorie tracking as default;
- USDA as universal database.

## v2 evidence package
- Mediterranean RCT meta-analyses through 2025.
- Dietary fiber mortality meta-analyses 2024.
- AGA 2024 iron deficiency anemia update.
- Vitamin B12 vegan functional-status meta-analysis 2024.
- Endocrine Society Vitamin D prevention guideline 2024.
- EFSA calcium and iodine DRVs.
- Omega-3 formulation-specific RCT meta-analyses.
- Creatine + resistance training meta-analyses 2024–2025.
- Caffeine performance systematic reviews 2024.
- UPF umbrella reviews 2024–2026 and NIH inpatient randomized feeding trial.
- DASH lipid meta-analysis 2025.

## v3 real-market sources
Current/near-current official and retailer snapshots include Alpro regional pages, Oatly UK, FAGE UK, Arla UK, Tesco UK, Mercadona product pages/price trackers, Myprotein ES/UK, Chobani US, plus deliberately stale/secondary sources to test source-quality handling.

## v4 everyday-system evidence
- Meal planning and diet quality: NutriNet-Santé observational study, PMID 28153017.
- Meal preparation enjoyment and self-rated diet quality, PMID 40910965.
- Restaurant/canteen healthy-meal interventions meta-analysis, PMID 33919552.
- Eating out of home scoping review, PMID 35334920.
- Household leftover food waste systematic review, PMID 37121486.
- Household food-waste behavior systematic reviews, PMIDs 39385555 and 37638683.
- WHO International Travel and Health / safer food for travellers guidance, 2025.

## v5 medical / physiology sources (searched 2026-08-23)
- ADA Standards of Care in Diabetes 2026, Section 5.
- KDIGO 2024 CKD Clinical Practice Guideline.
- ACG Clinical Guideline: IBS (PMID 33315591) + 2024 low-FODMAP umbrella review.
- 2025 AHA/ACC High Blood Pressure Guideline; 2024 ESC Hypertension Guideline.
- WHO antenatal nutrition / iron-folic acid / iodine recommendations.
- NOGG 2024 osteoporosis guideline.
- WHO haemoglobin cutoffs guideline 2024 and anaemia framework.
- EHA iron deficiency/IDA recommendations 2024; AGA IDA update 2024.
- WHO/IARC alcohol and cancer evidence / European Code Against Cancer 2025.
- EFSA Dietary Reference Values for water.
- EAACI IgE-mediated food allergy guideline 2024.

## v6 micronutrients / cooking sources (searched 2026-08-23)
- WHO Healthy Diet, updated 26 Jan 2026: micronutrient diversity and food-first framework.
- WHO Micronutrients and Food Fortification resources; 2025 vitamin A/D oil-fortification guideline.
- EFSA Dietary Reference Values / DRV Finder, page updated Oct 2025.
- EFSA DRV Summary Report and food-composition resources (reviewed 2026).
- EFSA current Upper Intake Level summary tables; updated B6, selenium, folate, iron, manganese and other UL/safe-level opinions.
- NIH Office of Dietary Supplements Health Professional Fact Sheets for nutrient-specific source/risk/interaction cross-checking.
- WHO Five Keys to Safer Food.
- USDA FSIS cooking-temperature / leftovers guidance used only as a US-specific example; local authority takes priority elsewhere.

## v7 coverage completion sources (checked 2026-08-23)
- Monash International Evidence-based PCOS Guideline 2023 and current 2026 PMOS resources.
- WHO breastfeeding and iodine supplementation resources.
- NHS/NHS England levothyroxine food, calcium, iron, soy and supplement interaction guidance.
- IOC 2023 RED-S consensus statement / REDs CAT2.
- Academy of Nutrition and Dietetics / Dietitians of Canada / ACSM sports nutrition position.
- Current endurance literature for race carbohydrate availability.
- MedlinePlus laboratory reference-range interpretation.
- ADA Standards of Care 2026 diagnosis/classification.
- Contemporary laboratory medicine literature on biological variation and reference change values.


## v7.1 Spain / Russia Tier-1 sources
- AESAN current healthy/sustainable dietary recommendations for Spain.
- AESAN Scientific Committee national reference-intake report (No. 29); EFSA live DRV for energy/macronutrients and updated nutrient values.
- AESAN fortification/vitamins-minerals rules; BEDCA food-composition system.
- Rospotrebnadzor MP 2.3.1.0253-21, still cited in 2025.
- FIC Nutrition and Biotechnology live chemical-composition database and 2024 updated Russian food-composition handbook.
- EAEU/CU TR TS 022/2011 food labelling rules.
- Rospotrebnadzor 2025 supplement/BAD consumer guidance.

## v7.2 quantitative + behavior/functional layer
- WHO Healthy Diet 2026: produce, fiber, sugars, fats, sodium.
- EFSA DRV principles/DRV Finder: population references are not individual goals.
- Rospotrebnadzor MR 2.3.1.0253-21: Russian population physiological-reference framework.
- GLP-1 multidisciplinary joint advisory 2025 (PMIDs 40445127 / 40450457).
- Time-restricted eating hunger meta-analysis 2025 (PMID 40318250).
- WHO non-sugar sweetener guideline 2023; explicitly distinct from toxicological ADI assessment.
- AGA probiotic guideline: strain/indication-specific recommendations.
- Fermented-food GI systematic review/meta-analysis 2025 (PMID 41141260).
- FDA grapefruit-drug interaction guidance.
