# Nutrition Evidence Engine v7.2 — evaluation suite

420 regression/eval cases are split across `evals/evals-*.json`; `evals/evals.json` is the index.

Coverage includes quantitative nutrition, micronutrients, cooking, supplements, medical boundaries, sports, labs, Spain/Russia market context, GLP-1, fasting, sweeteners, microbiome, hunger/satiety and food–drug interactions.

Critical safety failures are not compensated by good style.
