# Nutrition Evidence Engine v7.2

Универсальный доказательный Agent Skill для того, чтобы **реально хорошо питаться**, а не просто считать калории.

## Умеет
- строить рацион под человека;
- разбирать день/неделю;
- оценивать пищевой паттерн;
- считать энергию как диапазон;
- персонализировать белок/БЖУ;
- искать систематические микронутриентные пробелы;
- анализировать рецепты;
- создавать простые меню и покупки;
- учитывать веганство/вегетарианство и спорт;
- разбирать добавки;
- выбирать базу состава продуктов по стране;
- распознавать медицинские границы.

## Оптимизация
**достаточность × здоровье × цель × безопасность × удовольствие × реализуемость × цена**

## Текущая сборка v7.2
- `SKILL.md` — маршрутизатор;
- `references/` — 90 модулей;
- `evidence-cards/` — 54 научные карточки;
- `scripts/` — 26 детерминированных инструментов;
- `evals/` — 420 regression/eval кейсов;
- `assets/` — 60 лёгких recipe patterns;
- `benchmarks/` — real-market benchmark;
- `data/` и `schemas/` — политики, реестры и структуры данных.


## v2 — scientific core + problem-first

На 2026-08-23 добавлены 12 полноценных evidence-cards:
Mediterranean pattern, protein/training, fiber, iron, B12, vitamin D, calcium, iodine, omega-3, creatine, caffeine, ultra-processed foods.

Problem-first модули:
- снижение жировой массы;
- набор мышц;
- липиды/сердечно-сосудистый риск;
- полноценный растительный рацион.

Eval suite расширен до 100 кейсов.


## v3 — real food / supermarket benchmark

Добавлено:
- 25 реальных рыночных сущностей из Spain, UK, France/Belgium, USA и Australia;
- 36 market decision кейсов;
- 20 held-out кейсов;
- exact-region formula logic;
- label/version/source confidence;
- claims decompiler;
- current-price snapshot discipline;
- total sugar vs added/free sugar guard;
- fortification guard;
- `compare_labels.py`, `claim_decompiler.py`, `validate_benchmarks.py`.

Теперь продукт нельзя рекомендовать по слову `protein`, `zero`, `bio`, `natural`, `high fibre` или по одному €/100g.


## v4 — everyday nutrition operating system

Добавлены:
- daily system;
- low-effort mode;
- pantry/freezer system;
- flexible meal prep;
- restaurant/delivery mode;
- travel mode;
- food-waste logic;
- adaptive planner;
- grocery-list engine;
- social flexibility.

Eval suite: 166 кейсов.

Идея v4: рацион должен работать в реальные недели, включая delivery, рестораны, поездки и дни без готовки.


## v5 — medical / physiology layer

Добавлены 10 medical-context modules:
IBS, diabetes/glycemia, hypertension, CKD, pregnancy, menopause/bone health, anaemia, alcohol, hydration/electrolytes, food allergy.

Добавлены disease-specific evidence cards и 40 новых regression tests.

Главный принцип: disease-specific guideline имеет приоритет над generic healthy-eating/sports advice.


## v6 — Micronutrient Engine + Cooking & Easy Recipes

Добавлены:
- системный audit витаминов/минералов;
- 19 новых micronutrient evidence cards;
- registry с приоритетами, supplement/UL flags и lab caveats;
- gap → food → recipe workflow;
- cooking engine;
- substitution engine;
- inventory/photo-to-meal logic;
- equipment modes;
- recipe nutrition optimizer;
- global cooking safety layer;
- библиотека из 36 простых recipe patterns;
- `micronutrient_audit.py`, `micronutrient_food_fix.py`, `recipe_matcher.py`;
- eval suite расширен до 260 кейсов.

Главное: пользователь может просто написать «что приготовить из этого?» или «чего мне не хватает по рациону» — научная сложность остаётся внутри.


## v7 — Coverage Completion from gap-audit point 4 onward

Added:
- PMOS/PCOS, lactation and thyroid-food-medication modules;
- advanced endurance, RED-S, competition, weight-class and sweat/sodium sports modules;
- Lab Interpretation Engine + 6 lab-domain modules;
- versioned regional reference-system registry;
- cuisine × technique matrix with culturally adaptable food patterns;
- expanded easy-recipe library;
- automatic metadata/manifest synchronization;
- strict validator that fails on metadata/manifest drift.


## v7.1 — Spain + Russia Tier 1

Spain and Russian Federation are first-class country adapters, not generic examples.

Spain: AESAN + EFSA + BEDCA + exact Spanish labels.
Russia: Rospotrebnadzor MP 2.3.1.0253-21 + FIC Nutrition food-composition database/2024 handbook + EAEU label rules + exact Russian labels.

Adds country policy registry, country router and 20 regional regression tests.

## v7.2 — One physiology + Quantitative Core + behavioral/functional completion
- corrected Spain/Russia architecture: Tier-1 context, not different bodies;
- calories, protein, carbs, fats, fiber, free sugar, sodium, produce and hydration quantitative engine;
- GLP-1 nutrition;
- fasting/chrononutrition;
- sweeteners;
- microbiome/probiotics/fermented foods;
- hunger/satiety/cravings;
- food–drug interactions;
- functional foods/non-vitamin supplements;
- framework-comparison without border-dependent target switching.
